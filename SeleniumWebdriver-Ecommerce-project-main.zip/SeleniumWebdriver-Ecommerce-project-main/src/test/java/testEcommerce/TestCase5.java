package testEcommerce;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import POM.AddWishList;
import POM.RegisterPage;
import driver.driverFactory;

@Test
public class TestCase5 {
    public static void testCase5() {
        // implement Register page test case
        WebDriver driver = driverFactory.getChromeDriver();
        try {
            driver.get("http://live.techpanda.org/");
            RegisterPage registerPage = new RegisterPage(driver);
            AddWishList wishList = new AddWishList(driver);
            registerPage.register("An", "Pham", "anplhse173639@gmail.com", "haian123", "haian123");
            wishList.wishList("anplhse173639@fpt.edu.vn", "LG LCD");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
